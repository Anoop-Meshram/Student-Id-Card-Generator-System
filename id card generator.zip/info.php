<?php phpinfo(); ?>


